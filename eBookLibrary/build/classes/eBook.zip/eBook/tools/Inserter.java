package eBook.tools;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.sql.Date;

// Joseph Barsness

public class Inserter {
	public static void main(String[] args) throws SQLException {
	} 
}
